
def OUR(pred, mask, epoch):
    #OUR
    factor1 = 4
    factor2 = 6
    allepoch = 32
    pred1 = torch.sigmoid(pred)
    a = (epoch + 1) / (2 * allepoch)
    #weitp_m = 1 + (np.sin(a * 3.1415926)) * (1-pred1) * factor
    #weitm_p = 1 + (np.sin(a * 3.1415926)) * pred1 * factor
    weitp_m = 1 + (1 - pred1) * factor1 + np.sin(a * 3.1415926) * 0.5 * factor2
    weitm_p = 1 + pred1 * factor1 + np.sin(a * 3.1415926) * 0.5 * factor2
    weitzz1 = 1 + (1 - pred1) * factor1
    weitzz2 = 1 + pred1 * factor1
    wbce = F.binary_cross_entropy_with_logits(pred, mask, reduction='none')
    a = (((1 - pred1) * mask) * weitm_p) * wbce + ((pred1 * (1 - mask)) * weitp_m) * wbce + weitzz1 * (
                pred1 * mask) * wbce + weitzz2 * ((1 - pred1) * (1 - mask)) * wbce
    b = (((1 - pred1) * mask) * weitm_p) + ((pred1 * (1 - mask)) * weitp_m) + weitzz1 * (pred1 * mask) + weitzz2 * (
                (1 - pred1) * (1 - mask))
    wbce = a.sum(dim=(2, 3)) / b.sum(dim=(2, 3))
    return (wbce).mean()
